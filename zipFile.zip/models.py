"""
Database models for RefCheck AI multi-tenant system.
Implements user isolation, candidate management, and reference tracking.
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import Index, event
from sqlalchemy.dialects.postgresql import TSVECTOR
import uuid

db = SQLAlchemy()


def generate_uuid():
    return str(uuid.uuid4())


class User(UserMixin, db.Model):
    """User model for authentication and tenant isolation."""
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    company_name = db.Column(db.String(255))
    
    # Settings
    sms_template = db.Column(db.Text)
    timezone = db.Column(db.String(50), default='America/New_York')
    
    # API keys (encrypted in production)
    vapi_api_key = db.Column(db.String(255))
    vapi_phone_number_id = db.Column(db.String(255))
    twilio_account_sid = db.Column(db.String(255))
    twilio_auth_token = db.Column(db.String(255))
    twilio_phone_number = db.Column(db.String(50))
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login_at = db.Column(db.DateTime)
    
    # Relationships
    candidates = db.relationship('Candidate', backref='owner', lazy='dynamic',
                                  cascade='all, delete-orphan')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'company_name': self.company_name,
            'timezone': self.timezone,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class Candidate(db.Model):
    """Candidate model with full-text search support."""
    __tablename__ = 'candidates'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), 
                        nullable=False, index=True)
    
    # Basic info
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255))
    phone = db.Column(db.String(50))
    position = db.Column(db.String(255))
    
    # Resume data
    resume_text = db.Column(db.Text)
    resume_filename = db.Column(db.String(255))
    summary = db.Column(db.Text)
    skills = db.Column(db.Text)  # JSON array of skills
    
    # Status
    status = db.Column(db.String(50), default='intake')  # intake, in_progress, completed, archived
    
    # Settings
    sms_template = db.Column(db.Text)
    
    # Search optimization
    search_vector = db.Column(db.Text)  # Combined searchable text
    
    # Notes
    notes = db.Column(db.Text)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    jobs = db.relationship('Job', backref='candidate', lazy='dynamic',
                           cascade='all, delete-orphan', order_by='Job.order')
    references = db.relationship('Reference', backref='candidate', lazy='dynamic',
                                  cascade='all, delete-orphan')
    
    # Indexes
    __table_args__ = (
        Index('idx_candidate_user_status', 'user_id', 'status'),
    )
    
    def update_search_vector(self):
        """Update the search vector for full-text search."""
        parts = [
            self.name or '',
            self.email or '',
            self.position or '',
            self.summary or '',
            self.skills or '',
            self.notes or '',
            self.resume_text or ''
        ]
        # Add job info
        for job in self.jobs:
            parts.extend([job.company or '', job.title or ''])
        
        self.search_vector = ' '.join(parts).lower()
    
    def to_dict(self, include_jobs=False, include_references=False):
        result = {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'position': self.position,
            'summary': self.summary,
            'skills': self.skills,
            'status': self.status,
            'notes': self.notes,
            'resume_filename': self.resume_filename,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        
        if include_jobs:
            result['jobs'] = [job.to_dict() for job in self.jobs.order_by(Job.order)]
        
        if include_references:
            result['references'] = [ref.to_dict() for ref in self.references]
        
        return result
    
    def get_reference_progress(self):
        """Get reference check progress."""
        refs = list(self.references)
        total = len(refs)
        completed = len([r for r in refs if r.status == 'completed'])
        return {'completed': completed, 'total': total}
    
    def get_signal(self):
        """Calculate aggregate signal from completed references."""
        completed_refs = [r for r in self.references if r.status == 'completed' and r.score is not None]
        
        if not completed_refs:
            return {'score': None, 'label': 'No Data', 'color': 'gray'}
        
        avg_score = sum(r.score for r in completed_refs) / len(completed_refs)
        
        if avg_score >= 75:
            return {'score': round(avg_score), 'label': 'Strong', 'color': 'green'}
        elif avg_score >= 55:
            return {'score': round(avg_score), 'label': 'Moderate', 'color': 'yellow'}
        else:
            return {'score': round(avg_score), 'label': 'Concerns', 'color': 'red'}
    
    def get_reference_request_status(self):
        """Get the status of reference requests for this candidate."""
        requests = list(self.reference_requests)
        if not requests:
            return {'status': 'none', 'label': 'Not Requested'}
        
        # Get most recent request
        latest = max(requests, key=lambda r: r.created_at)
        
        if latest.status == 'completed':
            return {'status': 'completed', 'label': 'References Submitted', 'color': 'green'}
        elif latest.status == 'expired':
            return {'status': 'expired', 'label': 'Request Expired', 'color': 'red'}
        elif latest.is_valid():
            return {'status': 'pending', 'label': 'Awaiting Response', 'color': 'yellow'}
        else:
            return {'status': 'expired', 'label': 'Request Expired', 'color': 'red'}


class Job(db.Model):
    """Job history from candidate's resume."""
    __tablename__ = 'jobs'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    candidate_id = db.Column(db.String(36), db.ForeignKey('candidates.id', ondelete='CASCADE'),
                             nullable=False, index=True)
    
    company = db.Column(db.String(255), nullable=False)
    title = db.Column(db.String(255))
    dates = db.Column(db.String(100))
    order = db.Column(db.Integer, default=0)
    
    # JSON arrays
    responsibilities = db.Column(db.Text)  # JSON array
    achievements = db.Column(db.Text)  # JSON array
    
    def to_dict(self):
        import json
        return {
            'id': self.id,
            'company': self.company,
            'title': self.title,
            'dates': self.dates,
            'responsibilities': json.loads(self.responsibilities) if self.responsibilities else [],
            'achievements': json.loads(self.achievements) if self.achievements else []
        }


class Reference(db.Model):
    """Reference contact and check status."""
    __tablename__ = 'references'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    candidate_id = db.Column(db.String(36), db.ForeignKey('candidates.id', ondelete='CASCADE'),
                             nullable=False, index=True)
    job_id = db.Column(db.String(36), db.ForeignKey('jobs.id', ondelete='SET NULL'))
    
    # Contact info
    name = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(255))
    relationship = db.Column(db.String(100))  # e.g., "Manager", "Colleague"
    
    # Status
    status = db.Column(db.String(50), default='pending')
    # pending, calling, completed, failed, no_answer, scheduled
    
    # Call info
    call_id = db.Column(db.String(255))  # Vapi call ID
    scheduled_time = db.Column(db.DateTime)
    timezone = db.Column(db.String(50))
    
    # SMS
    sms_sent = db.Column(db.Boolean, default=False)
    sms_sent_at = db.Column(db.DateTime)
    sms_response = db.Column(db.Text)
    
    # Custom questions (JSON array)
    custom_questions = db.Column(db.Text)
    
    # Results
    score = db.Column(db.Integer)
    transcript = db.Column(db.Text)
    summary = db.Column(db.Text)
    sentiment = db.Column(db.String(50))
    
    # JSON fields for detailed results
    red_flags = db.Column(db.Text)  # JSON array
    discrepancies = db.Column(db.Text)  # JSON array
    achievements_verified = db.Column(db.Text)  # JSON array
    achievements_not_verified = db.Column(db.Text)  # JSON array
    positive_signals = db.Column(db.Text)  # JSON array
    structured_data = db.Column(db.Text)  # Full JSON analysis
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    # Relationship
    job = db.relationship('Job', backref='references')
    
    def to_dict(self):
        import json
        return {
            'id': self.id,
            'candidate_id': self.candidate_id,
            'job_id': self.job_id,
            'name': self.name,
            'phone': self.phone,
            'email': self.email,
            'relationship': self.relationship,
            'status': self.status,
            'call_id': self.call_id,
            'scheduled_time': self.scheduled_time.isoformat() if self.scheduled_time else None,
            'timezone': self.timezone,
            'sms_sent': self.sms_sent,
            'custom_questions': json.loads(self.custom_questions) if self.custom_questions else [],
            'score': self.score,
            'summary': self.summary,
            'sentiment': self.sentiment,
            'red_flags': json.loads(self.red_flags) if self.red_flags else [],
            'discrepancies': json.loads(self.discrepancies) if self.discrepancies else [],
            'achievements_verified': json.loads(self.achievements_verified) if self.achievements_verified else [],
            'achievements_not_verified': json.loads(self.achievements_not_verified) if self.achievements_not_verified else [],
            'positive_signals': json.loads(self.positive_signals) if self.positive_signals else [],
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }
    
    def get_result(self):
        """Get result summary for display."""
        import json
        if self.status != 'completed':
            return None
        return {
            'score': self.score,
            'red_flags': json.loads(self.red_flags) if self.red_flags else [],
            'discrepancies': json.loads(self.discrepancies) if self.discrepancies else [],
            'summary': self.summary,
            'sentiment': self.sentiment,
            'achievements_verified': json.loads(self.achievements_verified) if self.achievements_verified else [],
            'achievements_not_verified': json.loads(self.achievements_not_verified) if self.achievements_not_verified else []
        }


class ResumeFile(db.Model):
    """Stored resume files."""
    __tablename__ = 'resume_files'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    candidate_id = db.Column(db.String(36), db.ForeignKey('candidates.id', ondelete='CASCADE'),
                             nullable=False, index=True)
    
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255))
    content_type = db.Column(db.String(100))
    file_size = db.Column(db.Integer)
    file_data = db.Column(db.LargeBinary)  # Store file in DB for simplicity
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class ReferenceRequest(db.Model):
    """Request for candidate to submit their own references."""
    __tablename__ = 'reference_requests'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    candidate_id = db.Column(db.String(36), db.ForeignKey('candidates.id', ondelete='CASCADE'),
                             nullable=False, index=True)
    
    # Secure token for URL
    token = db.Column(db.String(64), unique=True, nullable=False, index=True)
    
    # Status: pending, completed, expired
    status = db.Column(db.String(20), default='pending')
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    completed_at = db.Column(db.DateTime)
    
    # Tracking
    email_sent_at = db.Column(db.DateTime)
    reminder_sent_at = db.Column(db.DateTime)
    
    # Relationship
    candidate = db.relationship('Candidate', backref='reference_requests')
    
    def is_valid(self):
        """Check if request is still valid (not expired, not completed)."""
        if self.status != 'pending':
            return False
        if datetime.utcnow() > self.expires_at:
            self.status = 'expired'
            return False
        return True
    
    def to_dict(self):
        return {
            'id': self.id,
            'candidate_id': self.candidate_id,
            'token': self.token,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'email_sent_at': self.email_sent_at.isoformat() if self.email_sent_at else None,
            'reminder_sent_at': self.reminder_sent_at.isoformat() if self.reminder_sent_at else None
        }


class AuditLog(db.Model):
    """Audit log for security and compliance."""
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.String(36), primary_key=True, default=generate_uuid)
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='SET NULL'), index=True)
    
    action = db.Column(db.String(100), nullable=False)
    resource_type = db.Column(db.String(50))  # candidate, reference, etc.
    resource_id = db.Column(db.String(36))
    details = db.Column(db.Text)  # JSON
    ip_address = db.Column(db.String(50))
    user_agent = db.Column(db.String(255))
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        Index('idx_audit_user_action', 'user_id', 'action'),
    )


# Event listeners for search vector updates
@event.listens_for(Candidate, 'before_insert')
@event.listens_for(Candidate, 'before_update')
def update_candidate_search_vector(mapper, connection, target):
    # Build search vector without accessing relationships to avoid session issues
    parts = [
        target.name or '',
        target.email or '',
        target.position or '',
        target.summary or '',
        target.skills or '',
        target.notes or '',
        target.resume_text or ''
    ]
    target.search_vector = ' '.join(parts).lower()
