"""
RefCheck AI - Production-ready multi-tenant reference verification system.
"""

import os
import json
import secrets
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, session
from flask_login import login_user, logout_user, login_required, current_user
from flask_migrate import Migrate
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

from models import db, User, Candidate, Job, Reference, ResumeFile, AuditLog, ReferenceRequest
from auth import (
    login_manager, validate_email, validate_password, log_audit,
    api_login_required, verify_resource_ownership, get_user_settings
)
from services import (
    extract_text_from_pdf, parse_resume_with_claude, analyze_transcript_with_claude,
    calculate_verification_score, generate_reference_questions, build_assistant_prompt,
    initiate_vapi_call, get_vapi_call_status, send_sms, format_sms_message,
    create_candidate_from_resume, search_candidates, DEFAULT_SMS_TEMPLATE,
    send_reference_request_email, send_reference_confirmation_email, send_reference_reminder_email
)

load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', os.urandom(32).hex())
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get(
    'DATABASE_URL', 
    'sqlite:///refcheck.db'
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB

# Handle PostgreSQL URL format from Heroku/Railway
if app.config['SQLALCHEMY_DATABASE_URI'].startswith('postgres://'):
    app.config['SQLALCHEMY_DATABASE_URI'] = app.config['SQLALCHEMY_DATABASE_URI'].replace(
        'postgres://', 'postgresql://', 1
    )

# Initialize extensions
db.init_app(app)
migrate = Migrate(app, db)
login_manager.init_app(app)

# Global API keys (shared across all users)
ANTHROPIC_API_KEY = os.environ.get('ANTHROPIC_API_KEY')
VAPI_API_KEY = os.environ.get('VAPI_API_KEY')
VAPI_PHONE_NUMBER_ID = os.environ.get('VAPI_PHONE_NUMBER_ID')
TWILIO_ACCOUNT_SID = os.environ.get('TWILIO_ACCOUNT_SID')
TWILIO_AUTH_TOKEN = os.environ.get('TWILIO_AUTH_TOKEN')
TWILIO_PHONE_NUMBER = os.environ.get('TWILIO_PHONE_NUMBER')
RESEND_API_KEY = os.environ.get('RESEND_API_KEY')

ALLOWED_EXTENSIONS = {'pdf', 'txt', 'doc', 'docx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# ============================================================================
# Database initialization
# ============================================================================

@app.before_request
def ensure_tables():
    """Ensure database tables exist."""
    if not hasattr(app, '_db_initialized'):
        with app.app_context():
            db.create_all()
        app._db_initialized = True


# ============================================================================
# Authentication Routes
# ============================================================================

@app.route('/register', methods=['GET', 'POST'])
def register():
    """User registration."""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        first_name = request.form.get('first_name', '').strip()
        last_name = request.form.get('last_name', '').strip()
        company_name = request.form.get('company_name', '').strip()
        
        errors = []
        
        if not email or not validate_email(email):
            errors.append("Please enter a valid email address")
        elif User.query.filter_by(email=email).first():
            errors.append("An account with this email already exists")
        
        if not first_name:
            errors.append("First name is required")
        if not last_name:
            errors.append("Last name is required")
        
        is_valid, password_error = validate_password(password)
        if not is_valid:
            errors.append(password_error)
        elif password != confirm_password:
            errors.append("Passwords do not match")
        
        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('register.html')
        
        # Create user
        user = User(
            email=email,
            first_name=first_name,
            last_name=last_name,
            company_name=company_name,
            sms_template=DEFAULT_SMS_TEMPLATE
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        log_audit(user.id, 'user_registered')
        
        login_user(user)
        flash('Welcome to RefCheck AI!', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login."""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        remember = request.form.get('remember') == 'on'
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            user.last_login_at = datetime.utcnow()
            db.session.commit()
            
            login_user(user, remember=remember)
            log_audit(user.id, 'user_login')
            
            next_page = request.args.get('next')
            if next_page and next_page.startswith('/'):
                return redirect(next_page)
            return redirect(url_for('dashboard'))
        
        flash('Invalid email or password', 'error')
        log_audit(None, 'failed_login', details={'email': email})
    
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    """User logout."""
    log_audit(current_user.id, 'user_logout')
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))


# ============================================================================
# Page Routes
# ============================================================================

@app.route('/')
def index():
    """Landing page or dashboard."""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('login.html')


@app.route('/health')
def health():
    """Health check endpoint for deployment."""
    return jsonify({'status': 'healthy'}), 200


@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard."""
    return render_template('dashboard.html')


@app.route('/candidate/new')
@login_required
def new_candidate():
    """New candidate intake page."""
    sms_template = current_user.sms_template or DEFAULT_SMS_TEMPLATE
    return render_template('new_candidate.html', sms_template=sms_template)


@app.route('/candidate/<candidate_id>')
@login_required
def view_candidate(candidate_id):
    """View candidate details."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard'))
    
    return render_template('candidate_detail.html', candidate_id=candidate_id)


@app.route('/settings')
@login_required
def settings():
    """User settings page."""
    return render_template('settings.html')


# ============================================================================
# API Routes - Candidates
# ============================================================================

@app.route('/api/candidates', methods=['GET'])
@api_login_required
def list_candidates():
    """List all candidates for the current user."""
    query = request.args.get('q', '').strip()
    status = request.args.get('status', '').strip() or None
    
    if query:
        candidates = search_candidates(current_user.id, query, status)
    else:
        base_query = Candidate.query.filter_by(user_id=current_user.id)
        if status:
            base_query = base_query.filter_by(status=status)
        candidates = base_query.order_by(Candidate.updated_at.desc()).all()
    
    result = []
    for c in candidates:
        progress = c.get_reference_progress()
        signal = c.get_signal()
        ref_request_status = c.get_reference_request_status()
        result.append({
            'id': c.id,
            'name': c.name,
            'position': c.position,
            'status': c.status,
            'reference_progress': progress,
            'signal': signal,
            'reference_request_status': ref_request_status,
            'created_at': c.created_at.isoformat() if c.created_at else None,
            'updated_at': c.updated_at.isoformat() if c.updated_at else None
        })
    
    return jsonify(result)


@app.route('/api/candidates', methods=['POST'])
@api_login_required
def create_candidate():
    """Create a new candidate from uploaded resume."""
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    position = request.form.get('position', '').strip()
    candidate_name = request.form.get('candidate_name', '').strip()
    sms_template = request.form.get('sms_template', current_user.sms_template or DEFAULT_SMS_TEMPLATE)
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type. Allowed: PDF, DOC, DOCX, TXT'}), 400
    
    try:
        # Read file
        file_data = file.read()
        filename = secure_filename(file.filename)
        
        # Extract text
        if filename.lower().endswith('.pdf'):
            resume_text = extract_text_from_pdf(file_data)
            if not resume_text:
                return jsonify({'error': 'Could not extract text from PDF'}), 400
        else:
            resume_text = file_data.decode('utf-8', errors='ignore')
        
        # Parse with Claude
        api_key = ANTHROPIC_API_KEY
        parsed = parse_resume_with_claude(resume_text, api_key)
        
        if not parsed:
            return jsonify({'error': 'Failed to parse resume'}), 500
        
        if candidate_name:
            parsed['candidate_name'] = candidate_name
        
        # Create candidate
        candidate = create_candidate_from_resume(
            current_user.id,
            parsed,
            resume_text=resume_text,
            resume_filename=filename
        )
        
        # Set position and SMS template
        candidate.position = position
        candidate.sms_template = sms_template
        
        # Store resume file
        resume_file = ResumeFile(
            candidate_id=candidate.id,
            filename=filename,
            original_filename=file.filename,
            content_type=file.content_type,
            file_size=len(file_data),
            file_data=file_data
        )
        db.session.add(resume_file)
        db.session.commit()
        
        log_audit(current_user.id, 'candidate_created', 'candidate', candidate.id)
        
        return jsonify({
            'candidate_id': candidate.id,
            'candidate': candidate.to_dict(include_jobs=True, include_references=True)
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/api/candidates/<candidate_id>', methods=['GET'])
@api_login_required
def get_candidate(candidate_id):
    """Get full candidate details."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    result = candidate.to_dict(include_jobs=True, include_references=True)
    result['signal'] = candidate.get_signal()
    result['reference_progress'] = candidate.get_reference_progress()
    
    return jsonify(result)


@app.route('/api/candidates/<candidate_id>', methods=['PATCH'])
@api_login_required
def update_candidate(candidate_id):
    """Update candidate details."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.json
    
    # Update allowed fields
    allowed_fields = ['position', 'status', 'sms_template', 'notes', 'name', 'email', 'phone']
    for field in allowed_fields:
        if field in data:
            setattr(candidate, field, data[field])
    
    candidate.updated_at = datetime.utcnow()
    db.session.commit()
    
    log_audit(current_user.id, 'candidate_updated', 'candidate', candidate.id)
    
    return jsonify(candidate.to_dict(include_jobs=True, include_references=True))


@app.route('/api/candidates/<candidate_id>', methods=['DELETE'])
@api_login_required
def delete_candidate(candidate_id):
    """Delete a candidate."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    log_audit(current_user.id, 'candidate_deleted', 'candidate', candidate.id,
              {'name': candidate.name})
    
    db.session.delete(candidate)
    db.session.commit()
    
    return jsonify({'success': True})


# ============================================================================
# API Routes - References
# ============================================================================

@app.route('/api/candidates/<candidate_id>/references', methods=['POST'])
@api_login_required
def add_reference(candidate_id):
    """Add a reference to a candidate."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.json
    
    # Get job if specified
    job_id = None
    job_index = data.get('job_index')
    if job_index is not None:
        jobs = list(candidate.jobs.order_by(Job.order))
        if 0 <= job_index < len(jobs):
            job_id = jobs[job_index].id
    
    reference = Reference(
        candidate_id=candidate.id,
        job_id=job_id,
        name=data.get('reference_name', ''),
        phone=data.get('reference_phone', ''),
        email=data.get('reference_email', ''),
        relationship=data.get('relationship', ''),
        custom_questions=json.dumps(data.get('custom_questions', [])),
        timezone=data.get('timezone', current_user.timezone or 'America/New_York'),
        status='pending'
    )
    
    db.session.add(reference)
    candidate.updated_at = datetime.utcnow()
    db.session.commit()
    
    log_audit(current_user.id, 'reference_added', 'reference', reference.id)
    
    return jsonify({'reference': reference.to_dict()})


@app.route('/api/candidates/<candidate_id>/references/<reference_id>', methods=['PATCH'])
@api_login_required
def update_reference(candidate_id, reference_id):
    """Update a reference."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    reference = Reference.query.get_or_404(reference_id)
    
    if reference.candidate_id != candidate.id:
        return jsonify({'error': 'Reference not found'}), 404
    
    data = request.json
    
    allowed_fields = ['name', 'phone', 'email', 'relationship', 'scheduled_time', 
                      'timezone', 'status', 'custom_questions', 'notes']
    
    for field in allowed_fields:
        if field in data:
            if field == 'custom_questions':
                reference.custom_questions = json.dumps(data[field])
            elif field == 'scheduled_time' and data[field]:
                reference.scheduled_time = datetime.fromisoformat(data[field].replace('Z', '+00:00'))
            else:
                setattr(reference, field, data[field])
    
    reference.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({'reference': reference.to_dict()})


@app.route('/api/candidates/<candidate_id>/references/<reference_id>', methods=['DELETE'])
@api_login_required
def delete_reference(candidate_id, reference_id):
    """Delete a reference."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    reference = Reference.query.get_or_404(reference_id)
    
    if reference.candidate_id != candidate.id:
        return jsonify({'error': 'Reference not found'}), 404
    
    db.session.delete(reference)
    db.session.commit()
    
    return jsonify({'success': True})


@app.route('/api/candidates/<candidate_id>/references/<reference_id>/schedule', methods=['POST'])
@api_login_required
def schedule_reference_call(candidate_id, reference_id):
    """Schedule a follow-up call."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    reference = Reference.query.get_or_404(reference_id)
    
    if reference.candidate_id != candidate.id:
        return jsonify({'error': 'Reference not found'}), 404
    
    data = request.json
    
    reference.scheduled_time = datetime.fromisoformat(data['scheduled_time'].replace('Z', '+00:00'))
    reference.timezone = data.get('timezone', 'America/New_York')
    reference.status = 'scheduled'
    reference.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    log_audit(current_user.id, 'call_scheduled', 'reference', reference.id)
    
    return jsonify({'success': True, 'reference': reference.to_dict()})


@app.route('/api/candidates/<candidate_id>/references/<reference_id>/send-sms', methods=['POST'])
@api_login_required
def send_reference_sms(candidate_id, reference_id):
    """Send SMS to a reference."""
    if not TWILIO_ACCOUNT_SID:
        return jsonify({'error': 'SMS not configured. Please contact administrator.'}), 500
    
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    reference = Reference.query.get_or_404(reference_id)
    
    if reference.candidate_id != candidate.id:
        return jsonify({'error': 'Reference not found'}), 404
    
    data = request.json or {}
    
    if data.get('message'):
        message = data['message']
    else:
        template = candidate.sms_template or current_user.sms_template or DEFAULT_SMS_TEMPLATE
        message = format_sms_message(template, candidate.name)
    
    from services import send_sms_global
    result = send_sms_global(reference.phone, message, TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER)
    
    if result.get('success'):
        reference.sms_sent = True
        reference.sms_sent_at = datetime.utcnow()
        db.session.commit()
        log_audit(current_user.id, 'sms_sent', 'reference', reference.id)
    
    return jsonify(result)


# ============================================================================
# API Routes - Calls
# ============================================================================

@app.route('/api/start-reference-check', methods=['POST'])
@api_login_required
def start_reference_check():
    """Start a single reference check call."""
    if not VAPI_API_KEY or not VAPI_PHONE_NUMBER_ID:
        return jsonify({'error': 'Vapi not configured. Please contact administrator.'}), 500
    
    data = request.json
    candidate_id = data.get('candidate_id')
    reference_id = data.get('reference_id')
    
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    reference = Reference.query.get_or_404(reference_id)
    
    if reference.candidate_id != candidate.id:
        return jsonify({'error': 'Reference not found'}), 404
    
    # Get the job for this reference
    job = reference.job
    if not job:
        jobs = list(candidate.jobs.order_by(Job.order))
        job = jobs[0] if jobs else None
    
    if not job:
        return jsonify({'error': 'No job information available'}), 400
    
    # Update status
    reference.status = 'calling'
    db.session.commit()
    
    # Initiate call with global credentials
    from services import initiate_vapi_call_global
    result = initiate_vapi_call_global(reference, candidate, job, VAPI_API_KEY, VAPI_PHONE_NUMBER_ID)
    
    if result.get('error'):
        reference.status = 'failed'
        db.session.commit()
        return jsonify(result), 500
    
    reference.call_id = result.get('call_id')
    db.session.commit()
    
    log_audit(current_user.id, 'call_initiated', 'reference', reference.id)
    
    return jsonify({'success': True, 'check_id': reference.call_id})


@app.route('/api/candidates/<candidate_id>/start-outreach', methods=['POST'])
@api_login_required
def start_outreach(candidate_id):
    """Begin reference outreach for all pending references."""
    if not VAPI_API_KEY or not VAPI_PHONE_NUMBER_ID:
        return jsonify({'error': 'Vapi not configured. Please contact administrator.'}), 500
    
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    candidate.status = 'in_progress'
    candidate.updated_at = datetime.utcnow()
    db.session.commit()
    
    from services import initiate_vapi_call_global
    results = []
    pending_refs = [r for r in candidate.references if r.status == 'pending']
    
    for reference in pending_refs:
        job = reference.job
        if not job:
            jobs = list(candidate.jobs.order_by(Job.order))
            job = jobs[0] if jobs else None
        
        if not job:
            results.append({
                'reference_id': reference.id,
                'reference_name': reference.name,
                'result': {'error': 'No job information'}
            })
            continue
        
        reference.status = 'calling'
        db.session.commit()
        
        call_result = initiate_vapi_call_global(reference, candidate, job, VAPI_API_KEY, VAPI_PHONE_NUMBER_ID)
        
        if call_result.get('error'):
            reference.status = 'failed'
        else:
            reference.call_id = call_result.get('call_id')
        
        db.session.commit()
        
        results.append({
            'reference_id': reference.id,
            'reference_name': reference.name,
            'result': call_result
        })
    
    log_audit(current_user.id, 'outreach_started', 'candidate', candidate.id)
    
    return jsonify({'success': True, 'results': results})


@app.route('/api/check-status/<check_id>', methods=['GET'])
@api_login_required
def check_call_status(check_id):
    """Get call status and results."""
    
    # Find the reference with this call_id
    reference = Reference.query.filter_by(call_id=check_id).first()
    
    if not reference:
        return jsonify({'error': 'Call not found'}), 404
    
    candidate = reference.candidate
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    # Get call status from Vapi using global credentials
    from services import get_vapi_call_status_global
    call_data = get_vapi_call_status_global(check_id, VAPI_API_KEY)
    
    if call_data.get('error'):
        return jsonify(call_data), 500
    
    status = call_data.get('status', 'unknown')
    ended_reason = call_data.get('endedReason', '')
    
    result = {
        'check_id': check_id,
        'status': status,
        'ended_reason': ended_reason
    }
    
    # Handle call completion
    if status == 'ended':
        if 'voicemail' in ended_reason.lower() or 'no-answer' in ended_reason.lower():
            reference.status = 'no_answer'
            
            # Auto-send SMS if configured
            if not reference.sms_sent and TWILIO_ACCOUNT_SID:
                template = candidate.sms_template or current_user.sms_template or DEFAULT_SMS_TEMPLATE
                message = format_sms_message(template, candidate.name)
                from services import send_sms_global
                sms_result = send_sms_global(reference.phone, message, TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER)
                if sms_result.get('success'):
                    reference.sms_sent = True
                    reference.sms_sent_at = datetime.utcnow()
        else:
            # Successful call - analyze transcript
            reference.status = 'completed'
            reference.completed_at = datetime.utcnow()
            
            artifact = call_data.get('artifact', {})
            transcript = artifact.get('transcript', '')
            
            reference.transcript = transcript
            result['transcript'] = transcript
            result['recording_url'] = artifact.get('recordingUrl')
            
            # Get job info for analysis
            job = reference.job
            if not job:
                jobs = list(candidate.jobs.order_by(Job.order))
                job = jobs[0] if jobs else None
            
            # Analyze with Claude
            if job and transcript:
                job_dict = job.to_dict()
                analysis = analyze_transcript_with_claude(
                    transcript, job_dict, candidate.name, ANTHROPIC_API_KEY
                )
                
                if analysis:
                    # Store analysis results
                    reference.score = calculate_verification_score(analysis)
                    reference.summary = analysis.get('summary', '')
                    reference.sentiment = analysis.get('overall_sentiment', 'neutral')
                    reference.red_flags = json.dumps(analysis.get('red_flags', []))
                    reference.discrepancies = json.dumps(analysis.get('discrepancies', []))
                    reference.achievements_verified = json.dumps(analysis.get('achievements_verified', []))
                    reference.achievements_not_verified = json.dumps(analysis.get('achievements_not_verified', []))
                    reference.positive_signals = json.dumps(analysis.get('positive_signals', []))
                    reference.structured_data = json.dumps(analysis)
                    
                    # Build result
                    red_flags = list(analysis.get('red_flags', []))
                    discrepancies = analysis.get('discrepancies', [])
                    
                    for disc in discrepancies:
                        if disc not in red_flags:
                            red_flags.append(f"DISCREPANCY: {disc}")
                    
                    if analysis.get('employment_confirmed') == False:
                        red_flags.append("Employment not confirmed by reference")
                    if analysis.get('dates_accurate') == False:
                        red_flags.append("Employment dates disputed by reference")
                    if analysis.get('title_confirmed') == False:
                        red_flags.append("Job title not confirmed by reference")
                    if analysis.get('would_rehire') == False:
                        red_flags.append("Reference would NOT rehire candidate")
                    
                    result.update({
                        'verification_score': reference.score,
                        'summary': reference.summary,
                        'red_flags': red_flags,
                        'discrepancies': discrepancies,
                        'achievements_verified': analysis.get('achievements_verified', []),
                        'achievements_not_verified': analysis.get('achievements_not_verified', []),
                        'positive_signals': analysis.get('positive_signals', []),
                        'structured_data': analysis
                    })
        
        db.session.commit()
        
        # Check if all references are done
        all_done = all(r.status in ['completed', 'failed', 'no_answer'] for r in candidate.references)
        if all_done:
            candidate.status = 'completed'
            db.session.commit()
    
    elif status == 'failed' or 'error' in status.lower():
        reference.status = 'failed'
        db.session.commit()
    
    return jsonify(result)


# ============================================================================
# API Routes - Settings
# ============================================================================

@app.route('/api/settings', methods=['GET'])
@api_login_required
def get_settings():
    """Get current user settings."""
    return jsonify({
        'email': current_user.email,
        'first_name': current_user.first_name,
        'last_name': current_user.last_name,
        'company_name': current_user.company_name,
        'timezone': current_user.timezone,
        'sms_template': current_user.sms_template or DEFAULT_SMS_TEMPLATE,
        'has_vapi': bool(current_user.vapi_api_key),
        'has_twilio': bool(current_user.twilio_account_sid),
        'vapi_phone_number_id': current_user.vapi_phone_number_id or ''
    })


@app.route('/api/settings', methods=['PATCH'])
@api_login_required
def update_settings():
    """Update user settings."""
    data = request.json
    
    # Profile fields
    if 'first_name' in data:
        current_user.first_name = data['first_name']
    if 'last_name' in data:
        current_user.last_name = data['last_name']
    if 'company_name' in data:
        current_user.company_name = data['company_name']
    if 'timezone' in data:
        current_user.timezone = data['timezone']
    if 'sms_template' in data:
        current_user.sms_template = data['sms_template']
    
    # API keys
    if 'vapi_api_key' in data:
        current_user.vapi_api_key = data['vapi_api_key'] or None
    if 'vapi_phone_number_id' in data:
        current_user.vapi_phone_number_id = data['vapi_phone_number_id'] or None
    if 'twilio_account_sid' in data:
        current_user.twilio_account_sid = data['twilio_account_sid'] or None
    if 'twilio_auth_token' in data:
        current_user.twilio_auth_token = data['twilio_auth_token'] or None
    if 'twilio_phone_number' in data:
        current_user.twilio_phone_number = data['twilio_phone_number'] or None
    
    current_user.updated_at = datetime.utcnow()
    db.session.commit()
    
    log_audit(current_user.id, 'settings_updated')
    
    return jsonify({'success': True})


@app.route('/api/settings/password', methods=['POST'])
@api_login_required
def change_password():
    """Change user password."""
    data = request.json
    
    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')
    confirm_password = data.get('confirm_password', '')
    
    if not current_user.check_password(current_password):
        return jsonify({'error': 'Current password is incorrect'}), 400
    
    is_valid, error = validate_password(new_password)
    if not is_valid:
        return jsonify({'error': error}), 400
    
    if new_password != confirm_password:
        return jsonify({'error': 'New passwords do not match'}), 400
    
    current_user.set_password(new_password)
    db.session.commit()
    
    log_audit(current_user.id, 'password_changed')
    
    return jsonify({'success': True})


# ============================================================================
# API Routes - Search
# ============================================================================

@app.route('/api/search', methods=['GET'])
@api_login_required
def search():
    """Search candidates."""
    query = request.args.get('q', '').strip()
    status = request.args.get('status', '').strip() or None
    
    candidates = search_candidates(current_user.id, query, status)
    
    result = []
    for c in candidates:
        result.append({
            'id': c.id,
            'name': c.name,
            'position': c.position,
            'status': c.status,
            'reference_progress': c.get_reference_progress(),
            'signal': c.get_signal()
        })
    
    return jsonify(result)


# ============================================================================
# Webhooks
# ============================================================================

# ============================================================================
# Reference Request Routes (Candidate Self-Service)
# ============================================================================

@app.route('/api/candidates/<candidate_id>/send-reference-request', methods=['POST'])
@api_login_required
def send_reference_request(candidate_id):
    """Send email to candidate requesting they submit references."""
    if not RESEND_API_KEY:
        return jsonify({'error': 'Email service not configured. Please add RESEND_API_KEY.'}), 500
    
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    if not candidate.email:
        return jsonify({'error': 'Candidate email is required. Please add their email first.'}), 400
    
    # Invalidate any existing pending requests
    existing_requests = ReferenceRequest.query.filter_by(
        candidate_id=candidate.id,
        status='pending'
    ).all()
    for req in existing_requests:
        req.status = 'expired'
    
    # Create new request
    token = secrets.token_urlsafe(32)
    ref_request = ReferenceRequest(
        candidate_id=candidate.id,
        token=token,
        status='pending',
        expires_at=datetime.utcnow() + timedelta(days=7)
    )
    db.session.add(ref_request)
    db.session.commit()
    
    # Send email
    base_url = request.url_root.rstrip('/')
    result = send_reference_request_email(candidate, token, base_url, RESEND_API_KEY)
    
    if result.get('success'):
        ref_request.email_sent_at = datetime.utcnow()
        db.session.commit()
        log_audit(current_user.id, 'reference_request_sent', 'candidate', candidate.id)
        return jsonify({'success': True, 'message': 'Reference request sent to candidate'})
    else:
        # Rollback the request if email failed
        ref_request.status = 'expired'
        db.session.commit()
        return jsonify({'error': f"Failed to send email: {result.get('error')}"}), 500


@app.route('/api/candidates/<candidate_id>/resend-reference-request', methods=['POST'])
@api_login_required
def resend_reference_request(candidate_id):
    """Resend/remind candidate to submit references."""
    if not RESEND_API_KEY:
        return jsonify({'error': 'Email service not configured.'}), 500
    
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    # Find existing pending request
    ref_request = ReferenceRequest.query.filter_by(
        candidate_id=candidate.id,
        status='pending'
    ).order_by(ReferenceRequest.created_at.desc()).first()
    
    if not ref_request or not ref_request.is_valid():
        # No valid request, send a new one
        return send_reference_request(candidate_id)
    
    # Send reminder
    base_url = request.url_root.rstrip('/')
    result = send_reference_reminder_email(candidate, ref_request.token, base_url, RESEND_API_KEY)
    
    if result.get('success'):
        ref_request.reminder_sent_at = datetime.utcnow()
        db.session.commit()
        log_audit(current_user.id, 'reference_reminder_sent', 'candidate', candidate.id)
        return jsonify({'success': True, 'message': 'Reminder sent to candidate'})
    else:
        return jsonify({'error': f"Failed to send reminder: {result.get('error')}"}), 500


@app.route('/api/candidates/<candidate_id>/reference-request-status', methods=['GET'])
@api_login_required
def get_reference_request_status(candidate_id):
    """Get the status of reference request for a candidate."""
    candidate = Candidate.query.get_or_404(candidate_id)
    
    if candidate.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    status = candidate.get_reference_request_status()
    
    # Get latest request details
    latest_request = ReferenceRequest.query.filter_by(
        candidate_id=candidate.id
    ).order_by(ReferenceRequest.created_at.desc()).first()
    
    if latest_request:
        status['request'] = latest_request.to_dict()
    
    return jsonify(status)


@app.route('/submit-references/<token>', methods=['GET'])
def submit_references_form(token):
    """Public page for candidate to submit references."""
    ref_request = ReferenceRequest.query.filter_by(token=token).first()
    
    if not ref_request:
        return render_template('submit_references.html', error='Invalid link'), 404
    
    if not ref_request.is_valid():
        db.session.commit()  # Save expired status
        return render_template('submit_references.html', error='This link has expired. Please contact the hiring team for a new link.'), 410
    
    candidate = ref_request.candidate
    jobs = list(candidate.jobs.order_by(Job.order))
    
    return render_template('submit_references.html', 
                          candidate=candidate, 
                          jobs=jobs, 
                          token=token,
                          error=None)


@app.route('/submit-references/<token>', methods=['POST'])
def submit_references(token):
    """Handle candidate's reference submission."""
    ref_request = ReferenceRequest.query.filter_by(token=token).first()
    
    if not ref_request:
        return render_template('submit_references.html', error='Invalid link'), 404
    
    if not ref_request.is_valid():
        db.session.commit()
        return render_template('submit_references.html', error='This link has expired.'), 410
    
    candidate = ref_request.candidate
    jobs = list(candidate.jobs.order_by(Job.order))
    
    # Parse form data
    references_added = 0
    
    for i, job in enumerate(jobs):
        # Reference 1 (required if any data provided)
        ref1_name = request.form.get(f'job_{i}_ref1_name', '').strip()
        ref1_phone = request.form.get(f'job_{i}_ref1_phone', '').strip()
        ref1_email = request.form.get(f'job_{i}_ref1_email', '').strip()
        ref1_relationship = request.form.get(f'job_{i}_ref1_relationship', '').strip()
        
        if ref1_name and ref1_phone:
            reference = Reference(
                candidate_id=candidate.id,
                job_id=job.id,
                name=ref1_name,
                phone=ref1_phone,
                email=ref1_email,
                relationship=ref1_relationship,
                status='pending'
            )
            db.session.add(reference)
            references_added += 1
        
        # Reference 2 (optional)
        ref2_name = request.form.get(f'job_{i}_ref2_name', '').strip()
        ref2_phone = request.form.get(f'job_{i}_ref2_phone', '').strip()
        ref2_email = request.form.get(f'job_{i}_ref2_email', '').strip()
        ref2_relationship = request.form.get(f'job_{i}_ref2_relationship', '').strip()
        
        if ref2_name and ref2_phone:
            reference = Reference(
                candidate_id=candidate.id,
                job_id=job.id,
                name=ref2_name,
                phone=ref2_phone,
                email=ref2_email,
                relationship=ref2_relationship,
                status='pending'
            )
            db.session.add(reference)
            references_added += 1
    
    # Validate at least 1 reference
    if references_added < 1:
        return render_template('submit_references.html',
                              candidate=candidate,
                              jobs=jobs,
                              token=token,
                              error='Please provide at least one reference.')
    
    # Mark request as completed
    ref_request.status = 'completed'
    ref_request.completed_at = datetime.utcnow()
    candidate.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    # Send confirmation email
    if RESEND_API_KEY:
        send_reference_confirmation_email(candidate, RESEND_API_KEY)
    
    return render_template('submit_references.html', 
                          success=True, 
                          references_added=references_added)


# ============================================================================
# Webhooks
# ============================================================================

@app.route('/api/webhook/vapi', methods=['POST'])
def vapi_webhook():
    """Handle Vapi call webhooks."""
    data = request.json or {}
    message_type = data.get('message', {}).get('type')
    call_id = data.get('message', {}).get('call', {}).get('id')
    
    if call_id:
        reference = Reference.query.filter_by(call_id=call_id).first()
        if reference and message_type == 'end-of-call-report':
            # Process will happen on next status check
            pass
    
    return jsonify({'success': True})


@app.route('/api/webhook/sms', methods=['POST'])
def sms_webhook():
    """Handle incoming SMS responses."""
    from_number = request.form.get('From', '')
    body = request.form.get('Body', '').strip()
    
    # Find reference by phone (normalize phone comparison)
    normalized = from_number[-10:] if len(from_number) >= 10 else from_number
    
    references = Reference.query.filter(
        Reference.phone.endswith(normalized)
    ).all()
    
    for reference in references:
        if reference.candidate.user_id:
            reference.sms_response = body
            reference.updated_at = datetime.utcnow()
            db.session.commit()
            break
    
    return '', 200


# ============================================================================
# Error Handlers
# ============================================================================

@app.errorhandler(404)
def not_found(e):
    if request.path.startswith('/api/'):
        return jsonify({'error': 'Not found'}), 404
    return render_template('404.html'), 404


@app.errorhandler(500)
def server_error(e):
    db.session.rollback()
    if request.path.startswith('/api/'):
        return jsonify({'error': 'Internal server error'}), 500
    return render_template('500.html'), 500


# ============================================================================
# CLI Commands
# ============================================================================

@app.cli.command('init-db')
def init_db():
    """Initialize the database."""
    db.create_all()
    print('Database initialized.')


@app.cli.command('create-admin')
def create_admin():
    """Create an admin user."""
    import getpass
    
    email = input('Email: ')
    password = getpass.getpass('Password: ')
    first_name = input('First name: ')
    last_name = input('Last name: ')
    
    user = User(
        email=email,
        first_name=first_name,
        last_name=last_name,
        sms_template=DEFAULT_SMS_TEMPLATE
    )
    user.set_password(password)
    
    db.session.add(user)
    db.session.commit()
    
    print(f'User {email} created.')


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', 'false').lower() == 'true'
    app.run(host='0.0.0.0', port=port, debug=debug)
